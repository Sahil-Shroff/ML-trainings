import azure.cognitiveservices.speech as speechsdk

# Set up the Speech Service configuration
def create_speech_config():
    speech_key = "FD8WMsALZoPHmPu4XqhRstKyQHCrDfjrumpQixYRxUuzYcXib6KgJQQJ99AKACYeBjFXJ3w3AAAYACOGkykd"
    service_region = "eastus"  # e.g., "eastus"
    return speechsdk.SpeechConfig(subscription=speech_key, region=service_region)

# Convert text to speech
def text_to_speech(text):
    # Create a speech configuration
    speech_config = create_speech_config()
    # Set the desired voice
    speech_config.speech_synthesis_voice_name = "en-US-AriaNeural"

    # Create a speech synthesizer
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)

    # Perform synthesis
    print(f"Converting text to speech: {text}")
    result = synthesizer.speak_text_async(text).get()

    # Check the result
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("Speech synthesized successfully.")
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        print(f"Speech synthesis canceled: {cancellation_details.reason}")
        if cancellation_details.error_details:
            print(f"Error details: {cancellation_details.error_details}")

if __name__ == "__main__":
    input_text = input("Enter text to convert to speech: ")
    text_to_speech(input_text)